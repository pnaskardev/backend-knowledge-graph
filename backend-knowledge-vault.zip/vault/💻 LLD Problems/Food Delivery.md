# Food Delivery

**One-liner:** 

**Why / when it's used:** 

**Key trade-off:** 

**Recall cue (write a Q, answer from memory later):**
- Q: 
- A: 

---
## 🔗 Connections
- [[Design Patterns]] · [[SAGA Pattern]] · [[Idempotency]] · [[Event-Driven Architectures]]

#lld #review
